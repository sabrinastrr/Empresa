package ultil; // Declaração do pacote onde a classe está localizada

import java.sql.Connection; // Importa a classe Connection do pacote java.sql
import java.sql.DriverManager; // Importa a classe DriverManager do pacote java.sql
import java.sql.SQLException; // Importa a classe SQLException do pacote java.sql

// Classe responsável por gerenciar a conexão com o banco de dados.
 
public class Conexao {
    private static final String URL = "jdbc:mysql://localhost:3306/empresa"; // URL do banco de dados
    private static final String USER = "devuser"; // Usuário do banco de dados
    private static final String PASSWORD = "123456"; // Senha do banco de dados

    // Método para estabelecer a conexão com o banco de dados.
    
    public static Connection conectar() throws ClassNotFoundException {
        Connection con = null; // Inicializa a conexão como nula
        try {
            // Carregar o driver JDBC
            Class.forName("com.mysql.cj.jdbc.Driver"); // Carrega o driver JDBC para MySQL
            // Estabelecer a conexão com o banco de dados
            con = DriverManager.getConnection(URL, USER, PASSWORD); // Tenta conectar ao banco de dados
            if (con != null) { // Verifica se a conexão foi estabelecida
                System.out.println("Conexão estabelecida com sucesso!"); // Mensagem de sucesso
            } else {
                System.out.println("Falha ao estabelecer conexão."); // Mensagem de falha
            }
        } catch (SQLException ex) { // Captura exceções de SQL
            System.err.println("Erro ao conectar com o banco: " + ex.getMessage()); // Mensagem de erro
            ex.printStackTrace(); // Adiciona a pilha de rastreamento para depuração
            throw new RuntimeException("Erro ao conectar com o banco de dados", ex); // Lança uma exceção em caso de erro
        }
        return con; // Retorna a conexão estabelecida
    }
}
